package cosmeticclient.gui.widgets;

import cosmeticclient.module.Module;
import cosmeticclient.module.settings.NumberSetting;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;

public class SliderWidget extends ClickableWidget {

    private Module module;
    private NumberSetting setting;

    public SliderWidget(int x, int y, int w, int h, Module m) {
        super(x, y, w, h, Text.literal(m.getName()));
        this.module = m;
    }

    public SliderWidget(int x, int y, int w, int h, NumberSetting s) {
        super(x, y, w, h, Text.literal(s.getName()));
        this.setting = s;
    }

    @Override
    protected void renderWidget(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        drawCenteredTextWithShadow(matrices, client.textRenderer, getMessage(), getX()+width/2, getY()+4, 0xFFFFFF);
    }

    @Override
    public void onClick(double mouseX, double mouseY) {
        if (module != null) module.toggle();
    }
}