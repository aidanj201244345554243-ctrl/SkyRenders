package cosmeticclient.module;

import cosmeticclient.modules.render.*;
import cosmeticclient.modules.hud.ModuleList;
import java.util.*;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public void init() {
        modules.add(new HitParticles());
        modules.add(new MotionBlur());
        modules.add(new ViewModel());
        modules.add(new Bloom());
        modules.add(new ModuleList());
    }

    public void tick() {
        for (Module m : modules) if (m.isEnabled()) m.onTick();
    }

    public List<Module> getModules() { return modules; }
}