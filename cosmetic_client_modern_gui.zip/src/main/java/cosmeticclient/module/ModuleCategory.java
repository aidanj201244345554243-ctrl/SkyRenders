package cosmeticclient.module;

public enum ModuleCategory {
    RENDER, HUD, MENU
}