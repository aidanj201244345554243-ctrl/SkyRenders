package cosmeticclient.module;

import cosmeticclient.module.settings.Setting;
import java.util.*;

public abstract class Module {
    private final String name;
    private final ModuleCategory category;
    private boolean enabled;
    protected final List<Setting<?>> settings = new ArrayList<>();

    public Module(String name, ModuleCategory category) {
        this.name = name;
        this.category = category;
    }

    public void toggle() { enabled = !enabled; if (enabled) onEnable(); else onDisable(); }
    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}

    public boolean isEnabled() { return enabled; }
    public String getName() { return name; }
    public ModuleCategory getCategory() { return category; }
    public List<Setting<?>> getSettings() { return settings; }
}