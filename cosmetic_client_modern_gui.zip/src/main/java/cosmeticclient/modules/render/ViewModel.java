package cosmeticclient.modules.render;

import cosmeticclient.module.*;
import cosmeticclient.module.settings.NumberSetting;

public class ViewModel extends Module {

    public NumberSetting scale = new NumberSetting("Scale", 1.0, 0.5, 2.0);

    public ViewModel() {
        super("ViewModel", ModuleCategory.RENDER);
        settings.add(scale);
    }
}