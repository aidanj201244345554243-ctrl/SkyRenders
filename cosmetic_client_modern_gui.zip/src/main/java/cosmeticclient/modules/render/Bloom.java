package cosmeticclient.modules.render;

import cosmeticclient.module.*;
import cosmeticclient.module.settings.NumberSetting;

public class Bloom extends Module {

    public NumberSetting intensity = new NumberSetting("Intensity", 0.6, 0.0, 1.0);

    public Bloom() {
        super("Bloom", ModuleCategory.RENDER);
        settings.add(intensity);
    }
}