package cosmeticclient.module.settings;

public class NumberSetting extends Setting<Double> {
    public final double min, max;

    public NumberSetting(String name, double def, double min, double max) {
        super(name, def);
        this.min = min;
        this.max = max;
    }
}