package cosmeticclient.gui;

import cosmeticclient.CosmeticClient;
import cosmeticclient.gui.widgets.SliderWidget;
import cosmeticclient.module.Module;
import cosmeticclient.module.settings.NumberSetting;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class ClickGuiScreen extends Screen {

    public ClickGuiScreen() { super(Text.literal("Cosmetic Client")); }

    @Override
    protected void init() {
        int y = 30;
        for (Module m : CosmeticClient.MODULES.getModules()) {
            addDrawableChild(new SliderWidget(20, y, 160, 16, m));
            y += 22;
            for (var s : m.getSettings()) {
                if (s instanceof NumberSetting ns) {
                    addDrawableChild(new SliderWidget(40, y, 140, 14, ns));
                    y += 18;
                }
            }
        }
    }

    @Override public boolean shouldPause() { return false; }
}