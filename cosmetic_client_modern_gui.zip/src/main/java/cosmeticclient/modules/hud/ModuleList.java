package cosmeticclient.modules.hud;

import cosmeticclient.module.*;

public class ModuleList extends Module {
    public ModuleList() { super("Module List", ModuleCategory.HUD); }
}