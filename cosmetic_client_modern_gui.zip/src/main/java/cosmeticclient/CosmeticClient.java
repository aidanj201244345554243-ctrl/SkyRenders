package cosmeticclient;

import cosmeticclient.gui.ClickGuiScreen;
import cosmeticclient.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import org.lwjgl.glfw.GLFW;

public class CosmeticClient implements ClientModInitializer {

    public static ModuleManager MODULES;
    private boolean guiDown = false;

    @Override
    public void onInitializeClient() {
        MODULES = new ModuleManager();
        MODULES.init();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            boolean pressed = GLFW.glfwGetKey(client.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_ALT) == GLFW.GLFW_PRESS;
            if (pressed && !guiDown) client.setScreen(new ClickGuiScreen());
            guiDown = pressed;
            MODULES.tick();
        });
    }
}