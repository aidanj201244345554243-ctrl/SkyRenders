package cosmeticclient.modules.render;

import cosmeticclient.module.*;
import cosmeticclient.module.settings.NumberSetting;

public class HitParticles extends Module {

    public NumberSetting amount = new NumberSetting("Amount", 10, 1, 50);

    public HitParticles() {
        super("Hit Particles", ModuleCategory.RENDER);
        settings.add(amount);
    }
}