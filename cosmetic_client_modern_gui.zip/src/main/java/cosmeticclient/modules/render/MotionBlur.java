package cosmeticclient.modules.render;

import cosmeticclient.module.*;
import cosmeticclient.module.settings.NumberSetting;

public class MotionBlur extends Module {

    public NumberSetting strength = new NumberSetting("Strength", 0.5, 0.0, 1.0);

    public MotionBlur() {
        super("Motion Blur", ModuleCategory.RENDER);
        settings.add(strength);
    }
}